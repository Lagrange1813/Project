//
//  TwicketSegmentedControl.h
//  TwicketSegmentedControl
//
//  Created by Pol Quintana on 17/09/16.
//  Copyright © 2016 Pol Quintana. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TwicketSegmentedControl.
FOUNDATION_EXPORT double TwicketSegmentedControlVersionNumber;

//! Project version string for TwicketSegmentedControl.
FOUNDATION_EXPORT const unsigned char TwicketSegmentedControlVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TwicketSegmentedControl/PublicHeader.h>


