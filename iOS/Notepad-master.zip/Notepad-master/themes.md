# Themes

## Base 16 Tomorrow
![](resources/swatches/base-16-tomorrow.png)

## One
![](resources/swatches/one.png)

## Solarized
![](resources/swatches/solarized.png)
