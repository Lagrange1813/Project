#Notepad
A simple Markdown editor.

Notepad gives your users the ability to **write and edit Markdown** directly in your app.

Oh, and did I mention that with a JSON styleshet it's *fully themeable*?

Add it to your app with only a few lines of `code`.

Enjoy.
