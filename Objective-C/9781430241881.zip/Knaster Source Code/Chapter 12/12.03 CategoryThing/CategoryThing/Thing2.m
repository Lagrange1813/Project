//
//  Thing2.m
//  CategoryThing
//
//  Created by Waqar Malik on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CategoryThing.h"

@implementation CategoryThing (Thing2)

- (void)setThing2:(NSInteger) t2
{
    thing2 = t2;
} // setThing2

- (NSInteger)thing2
{
    return (thing2);
} // thing2

@end // CategoryThing
