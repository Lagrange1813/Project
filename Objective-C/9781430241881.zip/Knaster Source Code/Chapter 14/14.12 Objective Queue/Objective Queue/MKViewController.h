//
//  MKViewController.h
//  Objective Queue
//
//  Created by Waqar Malik on 4/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MKViewController : UIViewController

- (IBAction)invokeOperation:(id)sender;
@end
