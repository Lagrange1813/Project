//
//  DisplayView.swift
//  SegmentedView
//
//  Created by 张维熙 on 2022/6/7.
//

import UIKit

class DisplayView: UIScrollView {


}
