/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The detail view controller in the Custom Back Button example.
*/

import UIKit

class CustomBackButtonDetailViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
