//
//  NotepadOSX.h
//  NotepadOSX
//
//  Created by Christian Tietze on 21.07.17.
//  Copyright © 2017 Rudd Fawcett. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for NotepadOSX.
FOUNDATION_EXPORT double NotepadOSXVersionNumber;

//! Project version string for NotepadOSX.
FOUNDATION_EXPORT const unsigned char NotepadOSXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NotepadOSX/PublicHeader.h>


