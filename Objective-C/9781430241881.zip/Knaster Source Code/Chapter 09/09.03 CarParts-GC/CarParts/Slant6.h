//
//  Slant6.h
//  CarParts
//
//  Created by Waqar Malik on 3/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Engine.h"

@interface Slant6 : Engine
@end // Slant6

