//
//  main.m
//  Count-1
//
//  Created by Waqar Malik on 4/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
	NSLog (@"The numbers from 1 to 5:");
	
	for (int i = 1; i <= 5; i++)
    {
		NSLog (@"%d\n", i);
	}
	
    return 0;
}

