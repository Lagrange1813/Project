//
//  Thing3.m
//  CategoryThing
//
//  Created by Waqar Malik on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CategoryThing.h"

@implementation CategoryThing (Thing3)

- (void)setThing3:(NSInteger) t3
{
    thing3 = t3;
} // setThing3

- (NSInteger)thing3
{
    return (thing3);
} // thing3

@end // CategoryThing
