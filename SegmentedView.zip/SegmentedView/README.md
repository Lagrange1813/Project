# README

融合 UIScrollView 和 UISegmentedController 的自定义控件。

### 更新记录

- 初始化 2022.6.6