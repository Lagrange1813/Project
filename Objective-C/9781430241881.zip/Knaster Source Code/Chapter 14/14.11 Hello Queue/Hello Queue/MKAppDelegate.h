//
//  MKAppDelegate.h
//  Hello Queue
//
//  Created by Waqar Malik on 4/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MKViewController;

@interface MKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MKViewController *viewController;

@end
