//
//  SegmentedView.h
//  SegmentedView
//
//  Created by 张维熙 on 2022/6/6.
//

#import <Foundation/Foundation.h>

//! Project version number for SegmentedView.
FOUNDATION_EXPORT double SegmentedViewVersionNumber;

//! Project version string for SegmentedView.
FOUNDATION_EXPORT const unsigned char SegmentedViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SegmentedView/PublicHeader.h>
