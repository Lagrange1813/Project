//
//  Notepad.h
//  Notepad
//
//  Created by Rudd Fawcett on 11/17/16.
//  Copyright © 2016 Rudd Fawcett. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Notepad.
FOUNDATION_EXPORT double NotepadVersionNumber;

//! Project version string for Notepad.
FOUNDATION_EXPORT const unsigned char NotepadVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Notepad/PublicHeader.h>


