//
//  main.m
//  Hello Objectivr-C
//
//  Created by Waqar Malik on 1/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{
    NSLog (@"Hello, Objective-C!");
    return 0;
}

