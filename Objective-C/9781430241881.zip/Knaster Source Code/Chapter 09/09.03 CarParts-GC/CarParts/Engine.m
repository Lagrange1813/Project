//
//  Engine.m
//  CarParts
//
//  Created by Waqar Malik on 3/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
#import "Engine.h"

@implementation Engine

- (NSString *) description
{
    return (@"I am an engine.  Vrooom!");
} // description

@end // Engine

