#Header 1
##Header 2
###Header 3

This is some **bold** text.
This is some *italic* text.
This is some `inline code`.
This is a custom @regex rule.

This is a custom [URL](http://google.com).
This is an image ![image description](http://google.com).
